public class ChallengeLab3 {
  public static void main(String[] args) {
    WallPaperUnit wp = new WallPaperUnit();
    wp.setName("Cotton");
    wp.setLength(12.5);
    wp.getName();
    wp.getLength();
  }
}
