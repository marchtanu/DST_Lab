//Name: Tanuphat Sojindamanee
//ID: 6887020
//Section: 1

public class CovidProfile {
  private String date = "2020-01-18";
  private String location = "Thailand";
  private int accumulatedCases = 17023;
  private int cureCases = 11396;
  private int deathCases = 76;

  public CovidProfile() {
    this.date = "none";
    this.location = "none";
    this.accumulatedCases = 0;
    this.cureCases = 0;
    this.deathCases = 0;
  }

  public CovidProfile(String date, String location, int noACC, int noCured, int noDeath) {
    this.date = date;
    this.location = location;
    this.accumulatedCases = noACC;
    this.cureCases = noCured;
    this.deathCases = noDeath;

  }

  public String getLocation() {
    return this.location;
  };

  public int getAccumulatedCases() {
    return this.accumulatedCases;
  };

  public int getCureCases() {
    return this.cureCases;
  };

  public int getDeathCases() {
    return this.deathCases;
  };

  public void setLocation(String loc) {
    this.location = loc;
  };

  public void setAccumulatedCases(int value) {
    this.accumulatedCases = value;
  };

  public void setCureCases(int value) {
    this.cureCases = value;
  };

  public void setDeathCases(int value) {
    this.deathCases = value;

  };

  public void printCovidinfo() {
    System.out.println(String.format("""
        %s at %s
        Accumulative Patient: %d
        Cured Patient: %d
        Death Case: %d
        """,
        this.location.toUpperCase(),
        this.date,
        this.accumulatedCases,
        this.cureCases,
        this.deathCases));
  }
}
