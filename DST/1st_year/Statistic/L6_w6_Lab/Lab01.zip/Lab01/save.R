library(rmarkdown)
library(knitr)
rmarkdown::render('Lab.R')
rmarkdown::render('Assignment.R')

